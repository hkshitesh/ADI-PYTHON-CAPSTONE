def reverse_string(s):
    return s[::-1]

def is_palindrome(s):
    return s == s[::-1]

def count_characters(s):
    return len(s)

def join_strings(s1, s2):
    return s1 + " " + s2
