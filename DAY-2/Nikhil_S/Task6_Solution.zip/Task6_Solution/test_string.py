import unittest
from string_functions import reverse_string, is_palindrome, count_characters, join_strings

class TestString(unittest.TestCase):
    def test_reverse(self):
        self.assertEqual(reverse_string("yes"),"sey")
        self.assertEqual(reverse_string("result"),"tluser")
        self.assertEqual(reverse_string("test"),"tset")

    def test_palindrome(self):
        self.assertEqual(is_palindrome("level"),True)
        self.assertEqual(is_palindrome("test"),False)
        self.assertEqual(is_palindrome("result"),False)

    def test_cntchar(self):
        self.assertEqual(count_characters("yes"),3)
        self.assertEqual(count_characters("level"),5)
        self.assertEqual(count_characters("result"),6)

    def test_joinstring(self):
        self.assertEqual(join_strings("Hello", "World"), "Hello World")
        self.assertEqual(join_strings("Good", "Morning"), "Good Morning")
        self.assertEqual(join_strings("Test", "Done"), "Test Done")


if __name__== '__main__':
    unittest.main()
