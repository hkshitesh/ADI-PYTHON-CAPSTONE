from my_package import module1, module2

print(module1.hello_module1())
print(module2.hello_module2())
