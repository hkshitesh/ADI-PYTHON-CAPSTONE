def hello_module2():
    return "Hello from Module 2"
