def hello_module1():
    return "Hello from Module 1"
